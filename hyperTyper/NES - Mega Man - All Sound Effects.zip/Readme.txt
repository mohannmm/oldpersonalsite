Mega Man / Rockman (NES)
Sound Effects ripped by Nai255

No credit needed, but feedback is welcome:
DoomedQuaker@hotmail.com

SPECIAL THANKS TO: zazer@earthlink.net / bsfree.org
for the Game Genie codes used in ripping these sounds